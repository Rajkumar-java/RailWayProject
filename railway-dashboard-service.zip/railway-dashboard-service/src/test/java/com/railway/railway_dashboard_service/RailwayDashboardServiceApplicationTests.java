package com.railway.railway_dashboard_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayDashboardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
