package com.railway.railway_report_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayReportServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RailwayReportServiceApplication.class, args);
	}

}
