package com.railway.railway_report_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayReportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
